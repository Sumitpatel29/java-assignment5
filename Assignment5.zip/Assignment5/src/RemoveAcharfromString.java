import java.util.Scanner;

public class RemoveAcharfromString {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter a string: ");
		String str=sc.nextLine();
		System.out.println("Enter character to remove");
		char ch=sc.next().charAt(0);

	}
	static void checkAchar(String str, char ch)
	{
		for (int i = 0; i < str.length(); i++)
		{
			if(str.charAt(i)==ch)
			{
				// remove ch from str
				
				
			}
		}
	}

}
