import java.util.Scanner;

public class BMI_Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter height in inches: ");
		int height=sc.nextInt();
		System.out.println("Enter weight in lbs: ");
		double weight=sc.nextDouble();
		calculateBMI(height, weight);

	}
	static void calculateBMI(int height,double weight)
	{
		double bmi=(703*(weight/height*height));
		System.out.println("BMI is "+ bmi);
		
//		if(bmi<18.5)
//		{
//			
//		}
//		else if(bmi>18.5 && bmi <24.9)
//		{
//			
//		}
//		else if(bmi>18.5 && bmi <24.9)
//		{
//			
//		}
	}

}
