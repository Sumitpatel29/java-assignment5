import java.util.Scanner;

public class CompareStrings 
{
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter 1st string: ");
		String str1= sc.nextLine();
		System.out.println("Enter 2nd string: ");
		String str2= sc.nextLine();
		
		System.out.println("Using compareTo:");
		System.out.println(str1.compareTo(str2));
		System.out.println("Using compareToIgnoreCase:");//returns unicode value in integer
		System.out.println(str1.compareToIgnoreCase(str2));
		sc.close();
	}

}
