
public class TempDays {

	public static void main(String[] args) 
	{
		int[] temps= {55,62,68,74,59,45,41,58,60,67,65,
				78,87,85,91,92,90,93,87,80,76,
				79,72,68,62,59};
		countTemp(temps);

	}
	
	static void countTemp(int[] temps)
	{
		int high=0, normal=0,low=0;
		
		for (int i : temps) 
		{
			//check if temps is >=85 then make it high
			if(i>=85)
			{
				high++;
			}
			else if(i>=60 && i<=84)
			{
				normal++;
			}
			else
			{
				low++;
			}
		}
		System.out.println("Number of High temperature Days:" +high);
		System.out.println("Number of Normal temperature Days:" +normal);
		System.out.println("Number of Low temperature Days:" +low);
	}

}
