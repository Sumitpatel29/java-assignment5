
public class LastOccurenceSubstring {
	public static void main(String[] args)
	{

	}
}
